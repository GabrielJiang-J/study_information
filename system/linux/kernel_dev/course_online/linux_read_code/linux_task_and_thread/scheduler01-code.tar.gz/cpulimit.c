main()
{
	while(1);
}
