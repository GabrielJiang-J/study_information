# 编译运行cow.c的例子，理解data变化的原理，解释打印的为什么是10,20,10
# 编译运行vfork.c的例子，理解data变化的原理，解释打印的为什么是10,20,20
# 编译gcc thread.c -pthread,用strace ./a.out跟踪其对clone()的调用
# 编译运行life_period.c，杀死父进程，用pstree命令观察子进程的被托孤
# 仔细阅读globalfifo.c的global_read()、globalfifo_write()函数，理解等待队列

